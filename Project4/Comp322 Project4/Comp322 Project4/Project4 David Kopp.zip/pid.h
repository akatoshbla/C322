//
//  pid.h
//  Comp322 Project4
//
//  Created by Sarah Christian-Kopp on 10/20/15.
//  Copyright © 2015 David Kopp. All rights reserved.
//

// File 1, pid.h
// This header file is included in pid.c and djk93533.c

#include <pthread.h>

#define PID_MIN  	300
#define PID_MAX 	350

/* mutex lock for accessing pid_map */
pthread_mutex_t mutex;

int pid_map[PID_MAX+1];

int last;	// last pid in use

void release_pid(int pid);
int allocate_pid(void);
int allocate_map(void);