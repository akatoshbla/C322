//
//  pid.c
//  Comp322 Project4
//
//  Created by Sarah Christian-Kopp on 10/20/15.
//  Copyright © 2015 David Kopp. All rights reserved.
//

//File 2, pid.c

#include "pid.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

#define PID_POOL 50

int* map; // 0 means avaliable / 1 means unavaliable

/**
 * Allocates the pid_map.
 */
int allocate_map(void)
{
    map = (int*)malloc(sizeof(int) * PID_POOL);
    
    if (map == NULL)
    {
        return -1;
    }
    int i;
    
    for (i = 0; i < PID_POOL; i++)
    {
        map[i] = 0;
    }
    
    return 1;
}

/**
 * Allocates a pid
 */
int allocate_pid(void)
{
    int i;
       
    for (i = 0; i < PID_POOL; i++)
    {
        if (map[i] == 0)
        {
            printf("%d", map[i]);
            map[i] = 1;
            return i + PID_MIN;
        }
    }
    
    //printf("PID Assigned = %d\n", (i + PID_MIN));
    return -1;
}

/**
 * Releases a pid
 */
void release_pid(int pid)
{
    pthread_mutex_lock(&mutex);
    map[pid - PID_MIN] = 0;
    //printf("%d", pid - PID_MIN);
    pthread_mutex_unlock(&mutex);
}